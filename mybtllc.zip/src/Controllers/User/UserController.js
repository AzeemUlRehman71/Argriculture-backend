const User = require('@Models/User');
const Response = require('@Formators/ApiResponseFormator');

function getFilter(data) {
  const filter = {};
  if (data.name) {
    filter.name = data.name;
  }
  if (data.email) {
    filter.email = data.email;
  }
  
  return filter;
}
module.exports = {

  async list(req, res) {
    try {
      console.log(req.body)
      let { body } = req
      const filter = await getFilter(body)
      const userList = await User.list(filter, body)
      if(userList){
        Response.successMsg(res, 3, userList);
      }else{
        Response.notFoundErr(res, 3, {});
      }
    } catch (e) {
      console.log(e.message)
      Response.serverErr(res, 1, e.message, {});
    }
  }
};