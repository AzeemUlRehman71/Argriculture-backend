const userRoute = require('@Routes/Admin/User')
const childRoute = require('@Routes/Admin/Child')

module.exports = {
    async register(app, prefix) {
        console.log('in admin routes...', prefix)
        userRoute.register(app, prefix);
        childRoute.register(app, prefix);
    }
}