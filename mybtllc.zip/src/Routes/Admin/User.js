const UserController = require('@Controllers/User/UserController');
const jwtMiddleware = require('@Middlewares/JWTMiddlware');
const validate = require('@Middlewares/ValidateMiddleware');
const schemas = require('@Validators/Schemas');

module.exports = {

    async register(app, prefix){
        app.post(`${prefix}user/list`, [validate(schemas.userList), jwtMiddleware.authenticateJWT], UserController.list);
    }
}